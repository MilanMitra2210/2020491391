import React from 'react'

const AllTrains = () => {
  return (
    <div>
      alltrains
    </div>
  )
}

export default AllTrains
